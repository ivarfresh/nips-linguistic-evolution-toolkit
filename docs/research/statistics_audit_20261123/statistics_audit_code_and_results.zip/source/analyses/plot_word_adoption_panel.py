#!/usr/bin/env python3
"""Paper Figure 5a (word adoption) and the supplementary meaning-similarity figure, one panel each.

Redraws the left panel of `linguistic_uptake.plot_excess` from the n = 10
reuse_summary.csv (both task orders pooled; the split is in
reuse_by_task_order.csv) and adds a legend. No API calls.

  python3 analyses/plot_word_adoption_panel.py
"""
from __future__ import annotations

from pathlib import Path
import sys

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analyses._shared import configure_matplotlib  # noqa: E402
from analyses.linguistic_uptake import stars  # noqa: E402

FIGS = ROOT / "docs/figures/linguistic_analysis_n10_20261001"
ORDER = [(2, "homogeneous"), (2, "mixed, other family"), (8, "homogeneous"),
         (8, "mixed, same family"), (8, "mixed, other family")]
LABELS = ["single-model\ndyads", "mixed dyads\nshown other\nfamily", "single-model\npopulations",
          "mixed populations\nshown same\nfamily", "mixed populations\nshown other\nfamily"]
SHOWN, UNSEEN = "#444444", "#bbbbbb"


def panel(summary: pd.DataFrame, metric: str, scale: float, ylabel: str, legend_loc: str, out: str) -> None:
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    fig, ax = plt.subplots(figsize=(6.5, 4.15))
    for x, (size, exp) in enumerate(ORDER):
        r = summary[(summary["size"] == size) & (summary["exposure"] == exp)].iloc[0]
        for dx, part, color in ((-0.18, "parent", SHOWN), (0.18, "null", UNSEEN)):
            ax.bar(x + dx, r[f"{metric}_{part}_mean"] * scale, width=0.34, color=color,
                   yerr=r[f"{metric}_{part}_ci"] * scale, capsize=3, error_kw=dict(lw=1, ecolor="#666666"))
        top = max(r[f"{metric}_parent_mean"] + r[f"{metric}_parent_ci"],
                  r[f"{metric}_null_mean"] + r[f"{metric}_null_ci"]) * scale
        ax.annotate(f"{stars(r[f'{metric}_excess_p_holm'])}\n{int(r[f'{metric}_excess_runs_positive'])}/{int(r['n_runs'])}",
                    (x, top), xytext=(0, 3), textcoords="offset points", ha="center", va="bottom", fontsize=7)
    ax.set_xticks(range(len(ORDER)), LABELS, fontsize=8)
    ax.set_ylabel(ylabel)
    ax.grid(axis="y", alpha=0.3)
    if metric == "cos":
        lo = min(summary["cos_null_mean"].min(), summary["cos_parent_mean"].min())
        ax.set_ylim(max(0, lo - 0.1), 1)
    else:
        ax.set_ylim(0, ax.get_ylim()[1] * 1.12)
    ax.legend(handles=[Patch(color=SHOWN, label="shown myth"), Patch(color=UNSEEN, label="unseen myth")],
              loc=legend_loc, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIGS / out, dpi=200)
    plt.close(fig)


def main() -> None:
    configure_matplotlib()
    summary = pd.read_csv(FIGS / "reuse_summary.csv")
    panel(summary, "adopt", 100, "% of new words adopted", "upper right", "language_reuse_words_only.png")
    # Supplementary meaning panel; the words panel it used to sit beside is Figure 5a.
    panel(summary, "cos", 1, "Similarity in meaning (cosine)", "upper right", "language_reuse_meaning_only.png")


if __name__ == "__main__":
    main()
